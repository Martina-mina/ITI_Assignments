﻿using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations; // مهم للـ validation

namespace iti_mvc_day5.Models // استبدل YourProjectName باسم مشروعك
{
    public class Student
    {
        public int Id { get; set; }

        [Required] // يضمن أن هذا الحقل مطلوب
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Display(Name = "Address")]
        public string Address { get; set; }

        [Display(Name = "Department")]
        public int DepartmentId { get; set; } // مفتاح خارجي للقسم

        // يمكنك إضافة علاقات مع كلاسات أخرى هنا
        // public virtual Department Department { get; set; }
    }
}