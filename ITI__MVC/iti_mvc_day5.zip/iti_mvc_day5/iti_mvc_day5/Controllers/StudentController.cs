using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using iti_mvc_day5.Models; // Make sure to replace this with your actual project's namespace
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//using System.Web.Mvc;
using Microsoft.AspNetCore.Mvc;


namespace iti_mvc_day5.Controllers
{
    public class StudentController : Controller
    {
        // Replace 'MyDbContext' with the name of your database context class
        private MyDbContext db = new MyDbContext();

        // Existing actions...

        // GET: Student/NewStudent
        public ActionResult NewStudent()
        {
            // Populate the dropdown list with departments from the database
            ViewBag.DepartmentId = new SelectList(db.Departments, "Id", "Name");
            return View(new Student());
        }

        // POST: Student/SaveNew
        [HttpPost]
        [ValidateAntiForgeryToken] // Recommended for security
        public ActionResult SaveNew(Student student)
        {
            if (ModelState.IsValid)
            {
                db.Students.Add(student);
                db.SaveChanges();
                return RedirectToAction("GetStsAllData"); // Redirect to the action that shows all students
            }

            // If the model state is not valid, return the same view with validation errors
            ViewBag.DepartmentId = new SelectList(db.Departments, "Id", "Name", student.DepartmentId);
            return View("NewStudent", student);
        }

        // Existing actions...
    }
}