﻿namespace iti_mvc_project.Models
{
    public class EventViewModel
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Date { get; set; }
        public string OrganizerName { get; set; }
        public bool UserHasBooked { get; set; }
        public int Id { get; set; }
    }
}
