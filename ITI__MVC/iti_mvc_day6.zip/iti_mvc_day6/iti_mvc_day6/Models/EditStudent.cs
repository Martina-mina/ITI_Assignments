﻿using Microsoft.AspNetCore.Mvc;

namespace iti_mvc_day6.Models
{
    
public IActionResult EditStudent(int id)
{
    var student = _context.Students.Find(id);
    if (student == null)
    {
        return NotFound();
    }
    return View(student);
}
}