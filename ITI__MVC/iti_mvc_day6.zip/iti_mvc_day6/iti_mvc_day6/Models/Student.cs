﻿namespace iti_mvc_day6.Models
{
  
public class Student
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Major { get; set; }
    // Add new fields
    public string UserName { get; set; }
    public string Password { get; set; }
}
}